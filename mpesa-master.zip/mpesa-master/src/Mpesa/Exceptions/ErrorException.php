<?php

namespace Kabangi\Mpesa\Exceptions;

use Exception;

class ErrorException extends Exception{
    
}
