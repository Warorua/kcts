<?php

namespace Kabangi\Mpesa\Exceptions;

use Exception;

class MpesaException extends Exception{
    
}
