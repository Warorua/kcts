<?php

namespace Kabangi\Mpesa\Exceptions;

use Exception;

class ConfigurationException extends Exception{
    
}
